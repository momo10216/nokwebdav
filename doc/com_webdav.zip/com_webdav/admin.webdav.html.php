<?

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

class HTML_spreadsheet {
	function show($option) {
	    global $my; ?>
<table class="contentpaneopen">
<tr><td class="contentheading" width="100%">
	WebDav Joomla Server
</td>
</tr>
</table>

<table class="contentpaneopen">
	<tr>
		<td width="70%" align="left" valign="top" colspan="2">
			<span class="small">
				Version 1.0
            </span>
		</td>
	</tr>
	<tr>
		<td valign="top" colspan="2">
            <p>
            	WebDav Joomla Server ist eine Komponente, die es erm�glicht einen Onlinespeicherplatz zu erstellen.<br>
        		Zur Zeit unterst�tzt diese Komponente nur den Zugriff f�r Super Administratoren.
            </p>
            <p>
            	Mit dieser Komponente kann man durch die gesamte Verzeichnisstruktur navigieren.<br>
                Es ist ebenfalls m�glich mit dieser Komponente ein Netzlaufwerk unter Windows oder einen Mountpoint
                unter Linux zu erstellen.
            </p>
		</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<a href="<?=$GLOBALS[mosConfig_live_site]?>/components/com_webdav/webdav.php/" target="_new" class="readon">
		   		WebDav-Verzeichnis ansehen
            </a>
		</td>
	</tr>
	<tr>
		<td valign="top" colspan="2">
            <p>
				<b>�ber WebDav</b><br>
				Web-based Distributed Authoring and Versioning (WebDAV) erlaubt Ihnen einen entfernten Webserver so zu verwenden,
                als wenn es ein lokaler Dateiserver w�re. Das hei�t, dass Sie Dateien und Ordner mit dem Dateimanager
                Ihres Computers hoch- und herunterladen k�nnen.
            </p><p>
				<b>Einrichtung unter Windows XP</b><br>
                <ol start="1" type="1">
					<li>Kopieren Sie folgende URL: <i><?=$GLOBALS[mosConfig_live_site]?>/components/com_webdav/webdav.php/</i></li>
                    <li>�ffnen Sie die Netzwerkumgebung</li>
                    <li>Klicken Sie auf Netzwerkresource hinzuf�gen</li>
                    <li>Als Internetadresse f�gen Sie die oben kopierte URL ein</li>
                    <li>Geben Sie Ihren Benutzernamen und Ihr Passwort ein</li>
                    <li>Zum Abschluss geben Sie nur mehr einen Namen f�r diese Verbindung ein</li>
				</ol>
            </p><p>
            <b>Andere Betriebssysteme</b><br>
            WebDav wird von fast allen Betriebssystemen unterst�tzt.
            <ul>
            	<li>Windows 98</li>
                <li>Windows 2000</li>
                <li>Windows XP</li>
                <li>Linux</li>
                <li>Mac OS X</li>
            </ul>
            Eine Anleitung f�r diese Betriebssystem wird in n�chster Zeit der Komponente hinzugef�gt.
            </p>
		</td>
	</tr>
</table>

<?
	}

}
?>