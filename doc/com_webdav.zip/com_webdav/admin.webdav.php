<?

defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once($mainframe->getPath('admin_html'));

$option = mosGetParam( $_REQUEST, 'option','');

switch($task) {
    default:
         HTML_spreadsheet::show($option);
         break;
} // Ende switch($task)


?>