<?

if (defined( '_VALID_MOS' )) {
?>
<table class="contentpaneopen">
<tr><td class="contentheading" width="100%">
	WebDav Joomla Server
</td>
</tr>
</table>

<table class="contentpaneopen">
	<tr>
		<td width="70%" align="left" valign="top" colspan="2">
			<span class="small">
				Version 1.0
            </span>
		</td>
	</tr>
	<tr>
		<td valign="top" colspan="2">
            <p>
            	WebDav Joomla Server ist eine Komponente, die es erm�glicht einen Onlinespeicherplatz zu erstellen.<br>
        		Zur Zeit unterst�tzt diese Komponente nur den Zugriff f�r Super Administratoren.
            </p>
            <p>
            	Mit dieser Komponente kann man durch die gesamte Verzeichnisstruktur navigieren.<br>
                Es ist ebenfalls m�glich mit dieser Komponente ein Netzlaufwerk unter Windows oder einen Mountpoint
                unter Linux zu erstellen.
            </p>
		</td>
	</tr>
	<tr>
		<td align="left" colspan="2">
			<a href="<?=$GLOBALS[mosConfig_live_site]?>/components/com_webdav/webdav.php/" target="_new" class="readon">
		   		WebDav-Verzeichnis ansehen
            </a>
		</td>
	</tr>
	<tr>
		<td valign="top" colspan="2">
            <p>
				<b>�ber WebDav</b><br>
				Web-based Distributed Authoring and Versioning (WebDAV) erlaubt Ihnen einen entfernten Webserver so zu verwenden,
                als wenn es ein lokaler Dateiserver w�re. Das hei�t, dass Sie Dateien und Ordner mit dem Dateimanager
                Ihres Computers hoch- und herunterladen k�nnen.
            </p><p>
				<b>Einrichtung unter Windows XP</b><br>
                <ol start="1" type="1">
					<li>Kopieren Sie folgende URL: <i><?=$GLOBALS[mosConfig_live_site]?>/components/com_webdav/webdav.php/</i></li>
                    <li>�ffnen Sie die Netzwerkumgebung</li>
                    <li>Klicken Sie auf Netzwerkresource hinzuf�gen</li>
                    <li>Als Internetadresse f�gen Sie die oben kopierte URL ein</li>
                    <li>Geben Sie Ihren Benutzernamen und Ihr Passwort ein</li>
                    <li>Zum Abschluss geben Sie nur mehr einen Namen f�r diese Verbindung ein</li>
				</ol>
            </p><p>
            <b>Andere Betriebssysteme</b><br>
            WebDav wird von fast allen Betriebssystemen unterst�tzt.
            <ul>
            	<li>Windows 98</li>
                <li>Windows 2000</li>
                <li>Windows XP</li>
                <li>Linux</li>
                <li>Mac OS X</li>
            </ul>
            Eine Anleitung f�r diese Betriebssystem wird in n�chster Zeit der Komponente hinzugef�gt.
            </p>
		</td>
	</tr>
</table>


<?
} else {

include '../../configuration.php';

include_once($mosConfig_absolute_path ."/components/com_webdav/authenticate.php");

ini_set("default_charset", "UTF-8");
ini_set("error_reporting", "0");

$realm = 'Restricted area Keyphrene';
$DBUSER = $GLOBALS['mosConfig_user'];
$DBPWD = $GLOBALS['mosConfig_password'];
$DBHOST = $GLOBALS['mosConfig_host'];
$DB_WEBDAV = $GLOBALS['mosConfig_db'];
$DB_PREFIX = $GLOBALS['mosConfig_dbprefix'];


$users = array();

mysql_connect($DBHOST,$DBUSER,$DBPWD);

mysql_select_db($DB_WEBDAV);

  $abfrage = mysql_query ("SELECT * FROM " .$DB_PREFIX ."users WHERE usertype = 'Super Administrator';");
  $reihen = mysql_num_rows($abfrage);
   if ($reihen <= 0) {
	header('WWW-Authenticate: Basic realm="'.$realm.'"');
	header('HTTP/1.0 401 Unauthorized');
	die('401 Unauthorized');
	return FALSE;
   } else {
      while ($row = mysql_fetch_object ($abfrage)) {
            $myusername = $row-> username;
            $mypassword = $row-> password;

            $users[$myusername] = $mypassword;
        }
      }

unset($users[0]);

AuthenticationDigestHTTP($realm, $users);
//AuthenticationBasicHTTP($realm, $users);


require_once "filesystem.php";

$server = new HTTP_WebDAV_Server_Filesystem();
$server->db_host = $DBHOST;
$server->db_name = $DB_WEBDAV;
$server->db_user = $DBUSER;
$server->db_passwd = $DBPWD;
$server->db_prefix = $DB_PREFIX;
$server->ServeRequest($_SERVER['DOCUMENT_ROOT']);
}

?>