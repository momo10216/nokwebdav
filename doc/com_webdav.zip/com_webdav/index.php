<?
echo "Zugriff verweigert!"
?>